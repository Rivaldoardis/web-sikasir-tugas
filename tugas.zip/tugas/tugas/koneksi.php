<?php  

date_default_timezone_set('ASIA/JAKARTA');
$kon = mysqli_connect("localhost", "root", "", "db_restoran");

?>