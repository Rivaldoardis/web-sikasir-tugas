<?php
session_start();
require '../../koneksi.php';

$meja = htmlspecialchars($_POST['meja']);
$id_order = htmlspecialchars($_POST['id_order']);
$keterangan = htmlspecialchars($_POST['keterangan']);
$id_user = $_SESSION['id_user'] ?? null;  // Gunakan null jika tidak diatur

// Periksa apakah pengguna sudah login
if ($id_user === null) {
    // Tangani kesalahan jika pengguna belum login
    $_SESSION['pesan'] = '
        <div class="alert alert-danger mb-2 alert-dismissible text-small " role="alert">
            <b>Error!</b> Pengguna belum login.
            <button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
        </div>
    ';
    header('location:../index.php');
    exit;  // Hentikan skrip
}

$tanggal = time();
$tanggal2 = date('d-m-Y');

// Periksa apakah meja sudah dipilih
if ($meja < 1) {
    $_SESSION['pesan'] = '
		<div class="alert alert-warning mb-2 alert-dismissible text-small " role="alert">
			<b>Maaf!</b> Meja belum dipilih
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php');
    return false;
}

// Perbarui status meja tanpa kolom status_order
mysqli_query($kon, "UPDATE tb_meja SET status = 1 WHERE meja_id = '$meja'");

// Tambahkan pesanan baru ke dalam database
$queryTambah = "INSERT INTO tb_order VALUES('$id_order', '$meja', '$tanggal', '$tanggal2', '$id_user', '$keterangan', 0)";
$query = mysqli_query($kon, $queryTambah);

// Periksa apakah query berhasil
if ($query > 0) {
    $_SESSION['pesan'] = '
		<div class="alert alert-success mb-2 alert-dismissible text-small " role="alert">
			<b>Yoi!</b> Pesanan sedang diproses, mohon tunggu sampai masakan datang
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php');
} else {
    $_SESSION['pesan'] = '
		<div class="alert alert-danger mb-2 alert-dismissible text-small " role="alert">
			<b>Maaf!</b> Pesanan gagal diproses
			<button type="button" class="close" data-dismiss="alert" aria-label="close"><span aria-hidden="true">&times;</span></button>
		</div>
	';
	header('location:../index.php');
}
?>
